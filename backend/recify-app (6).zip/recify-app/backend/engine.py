"""
The actual product. Every function here is deterministic arithmetic on real
rows from the database — nothing is generated or guessed by an LLM. That's
deliberate: a risk score or an aging bucket has to be exactly reproducible
and explainable to a customer, and it has to still work the day Recify's
subscription to any AI vendor lapses.
"""
from datetime import date, datetime
from collections import defaultdict

AGING_BUCKETS = [
    ("current", "Current (not yet due)", None, 0),
    ("d1_30",   "1–30 days overdue", 1, 30),
    ("d31_60",  "31–60 days overdue", 31, 60),
    ("d61_90",  "61–90 days overdue", 61, 90),
    ("d90_plus","90+ days overdue", 91, None),
]

def _parse(d):
    return datetime.fromisoformat(d).date() if isinstance(d, str) else d

def days_overdue(due_date, as_of=None):
    as_of = as_of or date.today()
    return (as_of - _parse(due_date)).days


def compute_aging(invoices, as_of=None):
    """
    invoices: list of dicts with id, customer_id (or customer name), amount, due_date, status
    Returns bucketed totals + the invoices in each bucket, for open (unpaid) invoices only.
    """
    buckets = {key: {"label": label, "min": lo, "max": hi, "value": 0.0, "count": 0, "items": []}
               for key, label, lo, hi in AGING_BUCKETS}

    for inv in invoices:
        if inv["status"] == "paid":
            continue
        d = days_overdue(inv["due_date"], as_of)
        for key, label, lo, hi in AGING_BUCKETS:
            if lo is None and d <= 0:
                bucket_key = key; break
            if lo is not None and hi is None and d >= lo:
                bucket_key = key; break
            if lo is not None and hi is not None and lo <= d <= hi:
                bucket_key = key; break
        else:
            bucket_key = "current" if d <= 0 else "d90_plus"
        b = buckets[bucket_key]
        b["value"] += inv["amount"]
        b["count"] += 1
        b["items"].append({**inv, "days_overdue": d})

    return list(buckets.values())


def generate_aging_insights(buckets, critical_days=None):
    """Templates filled with real computed numbers — see docstring above."""
    critical_days = DEFAULT_SETTINGS["critical_days"] if critical_days is None else critical_days
    total = sum(b["value"] for b in buckets)
    insights = []
    all_items = [it for b in buckets for it in b["items"]]
    risk_items = [it for it in all_items if it["days_overdue"] > critical_days]
    risk_total = sum(it["amount"] for it in risk_items)

    if risk_total > 0 and total > 0:
        pct = round(risk_total / total * 100)
        by_cust = defaultdict(float)
        for item in risk_items:
            by_cust[item.get("customer_name", item.get("customer_id"))] += item["amount"]
        top_cust, top_amt = max(by_cust.items(), key=lambda kv: kv[1]) if by_cust else (None, 0)
        top_pct = round(top_amt / risk_total * 100) if risk_total else 0
        insights.append({
            "level": "risk" if pct > 25 else "warn",
            "tag": "Needs attention" if pct > 25 else "Worth watching",
            "text": (f"{fmt_money(risk_total)} ({pct}% of total outstanding) is more than {critical_days} days "
                     "overdue. "
                     + (f"{top_cust} alone accounts for {fmt_money(top_amt)} of that — {top_pct}% of the at-risk balance. "
                        if top_cust else "")
                     + "This is the money most likely to become a write-off if nothing changes.")
        })

    b90 = next((b for b in buckets if b["min"] and b["min"] >= 91), None)
    if b90 and b90["value"] > 0:
        insights.append({
            "level": "risk", "tag": "Past 90 days",
            "text": (f"{b90['count']} invoice(s) totaling {fmt_money(b90['value'])} have been outstanding "
                     "for more than 90 days. Recovery odds drop sharply past this point — worth a direct "
                     "collections call or a formal write-off decision this week.")
        })

    current = next(b for b in buckets if b["label"].startswith("Current"))
    healthy_pct = round(current["value"] / total * 100) if total else 0
    insights.append({
        "level": "info", "tag": "Overall",
        "text": (f"{healthy_pct}% of outstanding receivables ({fmt_money(current['value'])}) is still within "
                 f"terms. The remaining {fmt_money(total - current['value'])} is overdue and needs active follow-up.")
    })
    return insights


def reconcile_payments(invoices, payments):
    """
    invoices: list of dicts {id, amount, status, customer_id}
    payments: list of dicts {id, invoice_ref, amount, customer_id}
    Deterministic matching — same rules as the dashboard prototype:
    Matched / Partial / Overpaid / Duplicate / Unmatched.
    """
    by_id = {inv["id"]: inv for inv in invoices}
    seen = defaultdict(int)
    results = []

    for p in payments:
        inv = by_id.get(p["invoice_ref"])
        if inv is None:
            # fuzzy fallback: same customer, closest amount, not yet paid
            candidates = [i for i in invoices if i["customer_id"] == p["customer_id"] and i["status"] != "paid"]
            suggestion = min(candidates, key=lambda c: abs(c["amount"] - p["amount"])) if candidates else None
            results.append({**p, "match_status": "unmatched", "invoice": None,
                             "diff": None, "suggestion": suggestion, "stale_status": False})
            continue

        seen[p["invoice_ref"]] += 1
        if seen[p["invoice_ref"]] > 1:
            results.append({**p, "match_status": "duplicate", "invoice": inv,
                             "diff": p["amount"], "suggestion": None, "stale_status": False})
            continue

        diff = round(p["amount"] - inv["amount"], 2)
        if abs(diff) < 1:
            status = "matched"
        elif diff < 0:
            status = "partial"
        else:
            status = "overpaid"
        stale = status == "matched" and inv["status"] != "paid"
        results.append({**p, "match_status": status, "invoice": inv,
                         "diff": diff, "suggestion": None, "stale_status": stale})

    return results


def build_reconciled_ledger(invoices, payments):
    """
    THE single source of truth. Every payment is applied to its invoice
    according to fixed rules, and the result — not the raw imported
    status/amount — is what every other function in this file, and every
    page in the app, must read.

    Rules (mirrors the reconciliation categories, but applied to the
    ledger rather than just reported):
      - matched:    invoice -> paid, balance 0.
      - partial:    balance reduced by the payment amount; status -> 'partial'.
      - overpaid:   balance 0; the excess is recorded as a customer credit,
                    never subtracted from anyone else's balance.
      - duplicate:  a second payment against an already-covered invoice —
                    does NOT reduce the balance again; recorded as a credit
                    / refund-due item instead.
      - unmatched:  held in a separate "unapplied cash" bucket with the
                    closest same-customer open invoice suggested, rather
                    than silently discarded or silently guessed onto an
                    invoice.
      - stale status: a payment that fully covers an invoice the source
                    system still shows as open/disputed — the invoice is
                    corrected to Paid here, and the correction is logged
                    in plain language so it's never a silent change.

    Multiple payments against the same invoice are summed before the
    balance is computed, so two partials that together clear an invoice
    correctly result in Paid — not two independent "still partial" reads.

    Returns:
      invoices:  every invoice, with amount/status REPLACED by the
                 reconciled net balance / effective status. gross_amount,
                 paid_amount and raw_status are kept alongside for display
                 and audit — nothing about the original import is deleted.
      credits:   overpayments and duplicate payments — money owed back to
                 or held on behalf of a customer, never used to silently
                 offset a different invoice.
      unapplied_cash: payments that couldn't be tied to a real invoice.
      audit_log: one plain-English line per correction made, so a status
                 or balance change is never invisible.
    """
    by_id = {inv["id"]: inv for inv in invoices}
    applied = defaultdict(list)
    credits, unapplied_cash, audit_log = [], [], []
    seen_refs = defaultdict(int)

    for p in payments:
        inv = by_id.get(p.get("invoice_ref"))
        if inv is None:
            candidates = [i for i in invoices if i["customer_id"] == p["customer_id"]]
            suggestion = min(candidates, key=lambda c: abs(c["amount"] - p["amount"])) if candidates else None
            unapplied_cash.append({**p, "suggestion": suggestion})
            continue

        seen_refs[p["invoice_ref"]] += 1
        if seen_refs[p["invoice_ref"]] > 1:
            credits.append({
                "customer_id": p["customer_id"], "customer_name": p.get("customer_name") or inv.get("customer_name"),
                "amount": round(p["amount"], 2), "reason": "duplicate_payment",
                "detail": f"Payment {p['id']} duplicates an earlier payment already applied to {inv['id']} — "
                          f"not applied again; {fmt_money(p['amount'])} held as a credit/refund-due item.",
                "payment_id": p["id"], "invoice_id": inv["id"],
            })
            continue
        applied[inv["id"]].append(p)

    reconciled = []
    for inv in invoices:
        pays = applied.get(inv["id"], [])
        paid_amount = round(sum(p["amount"] for p in pays), 2)
        gross = inv["amount"]
        raw_status = inv["status"]
        balance = round(gross - paid_amount, 2)

        if balance <= 0.5:
            effective_status = "paid"
            if paid_amount > gross + 0.5:
                excess = round(paid_amount - gross, 2)
                credits.append({
                    "customer_id": inv["customer_id"], "customer_name": inv.get("customer_name"),
                    "amount": excess, "reason": "overpayment",
                    "detail": f"{inv['id']} was overpaid by {fmt_money(excess)} — held as a customer credit.",
                    "invoice_id": inv["id"],
                })
            if raw_status != "paid" and pays:
                audit_log.append(f"{inv['id']} ({inv.get('customer_name','')}): payment(s) "
                                  f"{', '.join(p['id'] for p in pays)} fully clear this invoice, but it was still "
                                  f"marked '{raw_status}' in the source data — corrected to Paid.")
            balance = 0.0
        elif paid_amount > 0:
            effective_status = "partial"
            if raw_status == "paid":
                audit_log.append(f"{inv['id']} ({inv.get('customer_name','')}): was marked Paid in the source data, "
                                  f"but only {fmt_money(paid_amount)} of {fmt_money(gross)} is matched by a payment — "
                                  f"corrected to Partial, {fmt_money(balance)} still outstanding.")
        else:
            effective_status = raw_status

        reconciled.append({
            **inv,
            "gross_amount": gross,
            "paid_amount": paid_amount,
            "amount": balance,
            "status": effective_status,
            "raw_status": raw_status,
            "applied_payment_ids": [p["id"] for p in pays],
        })

    return {"invoices": reconciled, "credits": credits, "unapplied_cash": unapplied_cash, "audit_log": audit_log}


def run_invariant_checks(overview, aging_buckets, scores, reconciled_invoices):
    """
    The four checks you asked for, computed independently of whatever the
    individual endpoints report, so a bug in one place can't hide itself
    by being consistent with itself. Returns pass/fail per check plus the
    actual numbers, never just a boolean.
    """
    eps = 1.0  # AED — float rounding tolerance
    checks = []

    aging_open_total = sum(b["value"] for b in aging_buckets)
    customers_total = round(sum(c["open_balance"] for c in scores), 2)
    invoices_total = round(sum(i["amount"] for i in reconciled_invoices if i["status"] != "paid"), 2)
    overview_total = overview["total_outstanding"]

    checks.append({
        "name": "Executive Summary total = Aging total = Customers total = Invoices total",
        "pass": max(overview_total, aging_open_total, customers_total, invoices_total)
                - min(overview_total, aging_open_total, customers_total, invoices_total) < eps,
        "values": {"executive_summary": overview_total, "aging": round(aging_open_total, 2),
                   "customers": customers_total, "invoices": invoices_total},
    })

    current_bucket = next(b for b in aging_buckets if b["label"].startswith("Current"))
    overdue_bucket_total = round(aging_open_total - current_bucket["value"], 2)
    checks.append({
        "name": "Aging buckets (excl. Current) sum to Executive Summary overdue total",
        "pass": abs(overdue_bucket_total - overview["total_overdue"]) < eps,
        "values": {"aging_overdue_buckets": overdue_bucket_total, "executive_summary_overdue": overview["total_overdue"]},
    })

    b61_90 = next((b for b in aging_buckets if b["min"] == 61 and b["max"] == 90), None)
    b90p = next((b for b in aging_buckets if b["min"] and b["min"] >= 91), None)
    sixty_plus_bucket_total = round((b61_90["value"] if b61_90 else 0) + (b90p["value"] if b90p else 0), 2)
    all_items = [it for b in aging_buckets for it in b["items"]]
    sixty_plus_banner_total = round(sum(it["amount"] for it in all_items if it["days_overdue"] > 60), 2)
    checks.append({
        "name": "60+ day figure = sum of 61-90 and 90+ buckets",
        "pass": abs(sixty_plus_bucket_total - sixty_plus_banner_total) < eps,
        "values": {"bucket_sum_61_plus": sixty_plus_bucket_total, "over_60_days_banner": sixty_plus_banner_total},
    })

    checks.append({
        "name": "No invoice both Paid and carrying a positive net balance",
        "pass": all(not (i["status"] == "paid" and i["amount"] > eps) for i in reconciled_invoices),
        "values": {"violations": [i["id"] for i in reconciled_invoices if i["status"] == "paid" and i["amount"] > eps]},
    })

    return checks


DEFAULT_SETTINGS = {
    "on_time_weight": 50,
    "late_weight": 30,
    "exposure_weight": 20,
    "critical_days": 60,     # aging cutoff used to flag "at risk" buckets/insights
    "min_probability": 0.15, # floor for cash-forecast collection probability
}

def fmt_money(n):
    return f"AED {n:,.0f}"

def score_customer(invoices_for_customer, payments_for_customer, settings=None):
    """
    Transparent, auditable credit score (0-100) — a real weighted formula,
    not a model output. Weights are configurable (see DEFAULT_SETTINGS /
    the Settings modal) and NOT hidden from Kinetics, on purpose, because
    "why did this customer get flagged" has to be a one-sentence answer,
    not a black box. Returns the full arithmetic breakdown, a plain-English
    reason, and the total, so the UI can show exactly how the number was
    built without anyone needing to read the formula.

    Expects reconciled invoices (see build_reconciled_ledger): "amount" is
    the net outstanding balance, "status" is the corrected effective
    status, and "gross_amount" (if present) is the original invoice value
    — used here so a customer's exposure ratio is measured against their
    true total business volume, not just what's currently unpaid.
    """
    s = {**DEFAULT_SETTINGS, **(settings or {})}
    w_ontime, w_late, w_exposure = s["on_time_weight"], s["late_weight"], s["exposure_weight"]

    if not invoices_for_customer:
        return None

    total = len(invoices_for_customer)
    paid = [i for i in invoices_for_customer if i["status"] == "paid"]
    overdue = [i for i in invoices_for_customer if i["status"] != "paid" and days_overdue(i["due_date"]) > 0]

    on_time_ratio = 1 - (len(overdue) / total) if total else 1
    avg_days_late = (sum(days_overdue(i["due_date"]) for i in overdue) / len(overdue)) if overdue else 0
    late_penalty = min(avg_days_late / 90, 1)  # caps out at 90+ days late
    exposure = sum(i["amount"] for i in overdue)
    portfolio_value = sum(i.get("gross_amount", i["amount"]) for i in invoices_for_customer)
    exposure_ratio = min(exposure / max(portfolio_value, 1), 1)

    on_time_pts = round(on_time_ratio * w_ontime, 1)
    late_pts = round((1 - late_penalty) * w_late, 1)
    exposure_pts = round((1 - exposure_ratio) * w_exposure, 1)
    total_score = round(max(0, min(100, on_time_pts + late_pts + exposure_pts)))

    on_time_count = total - len(overdue)
    if overdue:
        reason = f"Paid {on_time_count} of {total} on time; the rest average {round(avg_days_late)} days late."
    elif paid:
        reason = f"All {total} invoice(s) on time or current — no late payment history."
    else:
        reason = f"{total} invoice(s) on file, none yet due or paid — no track record yet."

    return {
        "total": total_score, "reason": reason,
        "on_time_points": on_time_pts, "on_time_max": w_ontime,
        "late_points": late_pts, "late_max": w_late,
        "exposure_points": exposure_pts, "exposure_max": w_exposure,
    }


def compute_cash_forecast(invoices, scores_by_customer, weeks=8, as_of=None, settings=None):
    """
    Probability-weighted cash flow forecast — no ML model, just a real,
    explainable rule: each open invoice's amount is weighted by a collection
    probability derived from that customer's own credit score (or a neutral
    default if we don't have one yet), then bucketed into the week it's due.
    Overdue invoices land in "This week" at a discounted probability, since
    they're still expected to be collected, just less reliably.
    """
    s = {**DEFAULT_SETTINGS, **(settings or {})}
    prob_floor = s["min_probability"]
    as_of = as_of or date.today()
    buckets = []
    for i in range(weeks):
        buckets.append({"week_index": i, "label": "This week" if i == 0 else f"Week {i+1}",
                         "expected": 0.0, "raw_open": 0.0, "count": 0})

    for inv in invoices:
        if inv["status"] == "paid":
            continue
        due = _parse(inv["due_date"])
        delta_days = (due - as_of).days
        week_idx = 0 if delta_days < 0 else min(delta_days // 7, weeks - 1)

        score = scores_by_customer.get(inv["customer_id"])
        if score is None:
            probability = 0.75  # neutral default for a customer with no history yet
        else:
            probability = max(prob_floor, min(0.97, score / 100))
        if delta_days < 0:
            # overdue invoices are discounted further the longer they've been late
            probability *= max(0.3, 1 - min(abs(delta_days), 120) / 150)
        probability = max(prob_floor, probability)

        b = buckets[week_idx]
        b["expected"] += inv["amount"] * probability
        b["raw_open"] += inv["amount"]
        b["count"] += 1

    for b in buckets:
        b["expected"] = round(b["expected"], 2)
        b["raw_open"] = round(b["raw_open"], 2)
    return buckets


def compute_overview(invoices, scores_by_customer_full):
    """KPIs for the executive summary — all direct aggregation, nothing modeled."""
    open_invoices = [i for i in invoices if i["status"] != "paid"]
    total_outstanding = sum(i["amount"] for i in open_invoices)
    overdue = [i for i in open_invoices if days_overdue(i["due_date"]) > 0]
    total_overdue = sum(i["amount"] for i in overdue)

    by_cust = defaultdict(float)
    for i in open_invoices:
        by_cust[i.get("customer_name", i["customer_id"])] += i["amount"]
    top_exposure = sorted(by_cust.items(), key=lambda kv: kv[1], reverse=True)[:3]

    at_risk_customers = [c for c in scores_by_customer_full if (c["score"] or 0) < 50 and c["open_balance"] > 0]

    return {
        "total_outstanding": round(total_outstanding, 2),
        "total_overdue": round(total_overdue, 2),
        "overdue_pct": round(total_overdue / total_outstanding * 100) if total_outstanding else 0,
        "open_invoice_count": len(open_invoices),
        "top_exposure": [{"name": n, "amount": round(a, 2)} for n, a in top_exposure],
        "at_risk_customers": at_risk_customers,
    }
